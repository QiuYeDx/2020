function mix=gmm_init(ncentres,data,kiter,covar_type)
%% ���룺
% ncentres:���ģ����Ŀ
% train_data:ѵ������
% kiter:kmeans�ĵ�������
%% �����
% mix:gmm�ĳ�ʼ��������


[dim,data_sz]=size(data');

mix.priors=ones(1,ncentres)./ncentres;
mix.centres=randn(ncentres,dim);
switch covar_type
case 'diag'
  % Store diagonals of covariance matrices as rows in a matrix
  mix.covars=ones(ncentres,dim);
case 'full'
  % Store covariance matrices in a row vector of matrices
  mix.covars=repmat(eye(dim),[1 1 ncentres]);
otherwise
  error(['Unknown covariance type ', mix.covar_type]);  
end


% Arbitrary width used if variance collapses to zero: make it 'large' so
% that centre is responsible for a reasonable number of points.
GMM_WIDTH=1.0;

%kmeans�㷨
% [mix.centres,options,post]=k_means(mix.centres,data);
[mix.centres,post]=k_means(mix.centres,data,kiter);

% Set priors depending on number of points in each cluster
cluster_sizes = max(sum(post,1),1);  % Make sure that no prior is zero
mix.priors = cluster_sizes/sum(cluster_sizes); % Normalise priors

switch covar_type
case 'diag'
  for j=1:ncentres
   % Pick out data points belonging to this centre
   c=data(find(post(:,j)),:);
   diffs=c-(ones(size(c,1),1)*mix.centres(j,:));
   mix.covars(j,:)=sum((diffs.*diffs),1)/size(c,1);
   % Replace small entries by GMM_WIDTH value
   mix.covars(j,:)=mix.covars(j,:)+GMM_WIDTH.*(mix.covars(j,:)<eps);
  end 
case 'full'
  for j=1:ncentres
   % Pick out data points belonging to this centre
   c=data(find(post(:,j)),:);
   diffs=c-(ones(size(c,1),1)*mix.centres(j,:));
   mix.covars(:,:,j)=(diffs'*diffs)/(size(c,1)+eps);
   % Add GMM_WIDTH*Identity to rank-deficient covariance matrices
   if rank(mix.covars(:,:,j))<dim
	mix.covars(:,:,j)=mix.covars(:,:,j)+GMM_WIDTH.*eye(dim);
   end
  end
otherwise
  error(['Unknown covariance type ', mix.covar_type]);
end

mix.ncentres=ncentres;
mix.covar_type=covar_type;

%=============================================================
function [centres,post]=k_means(centres,data,kiter)

[dim,data_sz]=size(data');
ncentres=size(centres,1); %�ص���Ŀ
[ignore,perm]=sort(rand(1,data_sz)); %��������˳��������
perm = perm(1:ncentres); %ȡǰncentres����Ϊ��ʼ�����ĵ����
centres=data(perm,:); %ָ����ʼ���ĵ�
id=eye(ncentres); %Matrix to make unit vectors easy to construct
for n=1:kiter
  % Save old centres to check for termination
  old_centres=centres; %�洢�ɵ�����,���ڼ�����ֹ����
  
  % Calculate posteriors based on existing centres
  d2=(ones(ncentres,1)*sum((data.^2)',1))'+...
     ones(data_sz,1)* sum((centres.^2)',1)-2.*(data*(centres')); %�������
 
  % Assign each point to nearest centre
  [minvals, index]=min(d2', [], 1);
  post=id(index,:);

  num_points = sum(post, 1);
  % Adjust the centres based on new posteriors
  for j = 1:ncentres
    if (num_points(j) > 0)
      centres(j,:) = sum(data(find(post(:,j)),:), 1)/num_points(j);
    end
  end

  % Error value is total squared distance from cluster centres
  e = sum(minvals);
  if n > 1
    % Test for termination
    if max(max(abs(centres - old_centres))) < 0.0001 & ...
        abs(old_e - e) < 0.0001
      return;
    end
  end
  old_e = e;
end














