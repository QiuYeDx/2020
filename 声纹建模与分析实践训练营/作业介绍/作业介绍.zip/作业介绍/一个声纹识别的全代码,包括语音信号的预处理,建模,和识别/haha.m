function haha()
fname=recordCallback;
py=f_risen;
y11=lubo;