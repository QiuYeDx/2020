[x,fs]=audioread('202012161421375fd9a771b7a08.mp3');
plot(x);
HaoAudioTxt('202012161421375fd9a771b7a08.mp3')
HaoAudioTxt('e.wav')